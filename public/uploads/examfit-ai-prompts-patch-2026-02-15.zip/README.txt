    ExamFit AI Prompt Patch (2026-02-15)

    Inhalt:
    - Fix: Hardcoded 'Automobilkaufleute' im Exam-Pool → dynamisch per Curriculum/Beruf.
    - Guard: Kontaminations-Filter gegen Autohaus/Werkstatt/Fahrzeug-Kontexte bei Nicht-Kfz-Berufen.
    - Prompt-Upgrades: Learning Course, Questions, Tutor, Oral Exam, Validation → berufsbezogen, prüfungsnah, weniger KI-Floskeln, mehr Tiefe.
    - Validation erweitert um Berufsbezug/SSOT + Kontaminations-Auto-Reject.

    Installation:
    - ZIP in Loveable / Repo Root entpacken und Dateien überschreiben (Pfadstruktur beibehalten).
    - Deploy Supabase Edge Functions wie gewohnt.

    Geänderte Dateien:
    - supabase/functions/package-generate-exam-pool/index.ts
- supabase/functions/generate-course-batch/index.ts
- supabase/functions/generate-questions/index.ts
- supabase/functions/improve-lesson/index.ts
- supabase/functions/ai-tutor/index.ts
- supabase/functions/oral-exam/index.ts
- supabase/functions/validate-content/index.ts
